<div class="wrapper">
	<div class="box">
		<div class="wrapper-inner">
			<div class="wrapper-body-inner">
				<?php require UC_ROOT.'/parts/section/header.php';?>
				<div class="container">
				<?php require UC_ROOT.'/pages/'.$page.'.php';?>
			</div>
			</div><!-- /.wrapper-body-inner -->
			<?php require UC_ROOT.'/parts/section/footer.php'; ?>
		</div><!-- /.wrapper-inner -->
	</div><!-- /.box -->
</div><!-- /.wrapper -->